At some point in the future this folder might be 
used to house different compilation units for
controlling different parts of the robot